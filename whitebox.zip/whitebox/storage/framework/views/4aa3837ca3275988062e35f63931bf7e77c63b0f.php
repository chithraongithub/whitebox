<?php $__env->startSection('title','First Question'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-2 d-flex">
        <div class="col-6">
            <h3 class="font-weight-bold px-3 py-3">Whitebox</h3>
        </div>
    </div>
    <div class="row no-gutters">
        <div class="col-12 text-left">
            <div class="tabs-container">
                <div class="elastic"></div>
                <ul class="nav nav-tabs" id="nav-tabs">
                    <li class="nav-item">
                        <a class="nav-link active" id="0" data-toggle="tab" aria-controls="tab1" href="javascript:void(0)" aria-expanded="true">Question No. 1</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="1" data-toggle="tab" aria-controls="tab2" href="<?php echo e(route('secondQuestion')); ?>" aria-expanded="true">Question No. 2</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="2" data-toggle="tab" aria-controls="tab3" href="<?php echo e(route('thirdQuestion')); ?>" aria-expanded="true">Question No. 3</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="row mt-4 px-5">
        <div class="col-12">
            <h5>Find the employee who made the most valuable sale?</h5>
            <div class="table-responsive mt-4">
                <table class="table table-hover table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Total Customers</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($employee['name']); ?></td>
                            <td><?php echo e($employee['email']); ?></td>
                            <td><?php echo e(count($employee['sales'])); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <h5>Answer:</h5>
            <div class="table-responsive mt-4">
                <table class="table table-hover table-stripped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Most Valuable Sale</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($employeeWithMostValuableSale['name']); ?></td>
                            <td><?php echo e($employeeWithMostValuableSale['email']); ?></td>
                            <td><?php echo e($mostValuableSale); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp-New\htdocs\whitebox\resources\views/first_question.blade.php ENDPATH**/ ?>